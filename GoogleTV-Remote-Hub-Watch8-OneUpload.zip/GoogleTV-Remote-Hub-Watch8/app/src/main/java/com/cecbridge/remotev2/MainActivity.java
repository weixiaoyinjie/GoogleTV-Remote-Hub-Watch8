package com.cecbridge.remotev2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Independent Wear OS client: Google TV Remote v2, no TV APK or phone relay. */
public final class MainActivity extends Activity {
    private static final int BG=0xff08090b, PANEL=0xff181b20, LIGHT=0xfff5f7fa,
            SUB=0xffaab2bd, ACCENT=0xff62d0c0, GREEN=0xff176657, RED=0xff713744;
    private static final String PREFS="google_tv_remote_v2"; // keep V3 pairing data
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final List<SavedApp> savedApps=new ArrayList<>();
    private SharedPreferences prefs;
    private EditText hostField, pinField;
    private TextView statusView, powerView;
    private LinearLayout appsGrid;
    private Button launchModeButton;
    private IdentityStore identity;
    private PairingClient pairing;
    private RemoteSession remote;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private WifiManager.MulticastLock multicastLock;
    private FrameLayout pageFrame;
    private TextView pageTitle;
    private final List<ScrollView> pages = new ArrayList<>();
    private int currentPage = 0;
    private float downX, downY;
    private boolean touchStartedInInput;
    private int controlHeight=40;
    private boolean compactDisplay;
    private static final String[] PAGE_NAMES={"方向遥控","媒体控制","启动电视应用","连接电视","首次配对","启动与设置"};
    private volatile boolean resolving;

    private static final class SavedApp {
        String name, target;
        SavedApp(String n,String t){name=n;target=t;}
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        int heightDp=Math.round(getResources().getDisplayMetrics().heightPixels/getResources().getDisplayMetrics().density);
        compactDisplay=heightDp<315;
        controlHeight=Math.max(32,Math.min(44,Math.round(heightDp*0.13f)));
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        restoreApps();
        disableLegacyShortcuts();
        buildUi();
        io.execute(() -> {
            try {
                identity=new IdentityStore(getApplicationContext());
                remote=createRemote();
                String host=prefs.getString("host", "");
                if(!host.isEmpty()&&!prefs.getString("tv_fingerprint", "").isEmpty())
                    connectInternal(host);
                else showStatus("首次使用：输入电视 IP，点击首次配对，并填写电视上的六位配对码",false);
            } catch(Exception e) { showStatus("初始化失败："+e.getMessage(),true); }
        });
    }

    private RemoteSession createRemote(){
        return new RemoteSession(identity,new RemoteSession.Listener(){
            @Override public void status(String s){showStatus(s,false);}
            @Override public void powerState(Boolean on){
                runOnUiThread(() -> {
                    if(powerView!=null)powerView.setText(on==null?"Google TV · 状态未知":
                            on?"Google TV · 正在运行":"Google TV · 待机");
                });
            }
        });
    }

    /** One native, round-safe page at a time; swiping UP advances to the next function. */
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(26),dp(compactDisplay?13:22),dp(26),dp(compactDisplay?7:13));
        setContentView(root);

        pageTitle=label(PAGE_NAMES[0]+" · 1/6",compactDisplay?15:18,LIGHT,true);
        pageTitle.setGravity(Gravity.CENTER);
        root.addView(pageTitle,new LinearLayout.LayoutParams(-1,dp(compactDisplay?21:27)));

        powerView=label("Google TV · 未连接",11,ACCENT,false);
        powerView.setGravity(Gravity.CENTER);
        powerView.setSingleLine(true);
        powerView.setEllipsize(TextUtils.TruncateAt.END);
        root.addView(powerView);
        gap(root,compactDisplay?2:5);

        pageFrame=new FrameLayout(this);
        root.addView(pageFrame,new LinearLayout.LayoutParams(-1,0,1));
        for(int i=0;i<PAGE_NAMES.length;i++){
            ScrollView scroll=new ScrollView(this);
            scroll.setFillViewport(false);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
            LinearLayout panel=new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(2),dp(2),dp(2),dp(5));
            scroll.addView(panel);
            pages.add(scroll);
            pageFrame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
            scroll.setVisibility(i==0?View.VISIBLE:View.GONE);
            switch(i){
                case 0:remotePage(panel);break;
                case 1:mediaPage(panel);break;
                case 2:appsPage(panel);break;
                case 3:connectionPage(panel);break;
                case 4:pairingPage(panel);break;
                case 5:settingsPage(panel);break;
            }
        }
        gap(root,3);
        statusView=label("正在初始化…",11,ACCENT,false);
        statusView.setMaxLines(2);
        statusView.setEllipsize(TextUtils.TruncateAt.END);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(5),dp(3),dp(5),dp(3));
        statusView.setBackground(bg(PANEL));
        statusView.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("运行状态").setMessage(statusView.getText()).setPositiveButton("关闭",null).show());
        root.addView(statusView,new LinearLayout.LayoutParams(-1,dp(compactDisplay?26:38)));
        gap(root,compactDisplay?2:4);
        LinearLayout nav=row(root);
        nav.setPadding(dp(13),0,dp(13),0);
        Button prev=button(nav,"◀ 上页",PANEL,1,()->goToPage(currentPage-1));
        prev.setContentDescription("上一页");
        Button next=button(nav,"下页 ▶",GREEN,1,()->goToPage(currentPage+1));
        next.setContentDescription("下一页");
        goToPage(0);
    }

    private void remotePage(LinearLayout p){
        // Compact 3x3 keypad: 9 original functions on a round display, no wasted rows.
        LinearLayout top=row(p);
        button(top,"⏻",GREEN,1,()->key(26,"电源切换"));
        button(top,"▲",PANEL,1,()->key(19,"向上"));
        button(top,"菜单",PANEL,1,()->key(82,"菜单"));
        gap(p,compactDisplay?3:6);
        LinearLayout middle=row(p);
        button(middle,"◀",PANEL,1,()->key(21,"向左"));
        button(middle,"确定",GREEN,1,()->key(23,"确定"));
        button(middle,"▶",PANEL,1,()->key(22,"向右"));
        gap(p,compactDisplay?3:6);
        LinearLayout bottom=row(p);
        button(bottom,"返回",PANEL,1,()->key(4,"返回"));
        button(bottom,"▼",PANEL,1,()->key(20,"向下"));
        button(bottom,"主页",PANEL,1,()->key(3,"主页"));
    }

    private void mediaPage(LinearLayout p){
        // One compact page for music AND video. Directional seeking kept separate.
        LinearLayout transport=row(p);
        button(transport,"⏮ 上个",PANEL,1,()->key(88,"上一个"));
        button(transport,"▶❚❚",GREEN,1,()->key(85,"播放/暂停"));
        button(transport,"下个 ⏭",PANEL,1,()->key(87,"下一个"));
        gap(p,compactDisplay?3:6);
        LinearLayout seek=row(p);
        button(seek,"⏪ 快退",PANEL,1,()->key(89,"快退"));
        button(seek,"■ 停止",RED,1,()->key(86,"停止播放"));
        button(seek,"快进 ⏩",PANEL,1,()->key(90,"快进"));
        gap(p,compactDisplay?3:6);
        LinearLayout directions=row(p);
        button(directions,"◀ 左 / 回退",PANEL,1,()->key(21,"左方向/回退"));
        button(directions,"右 / 前进 ▶",PANEL,1,()->key(22,"右方向/前进"));
        gap(p,4);
        p.addView(smallNote("媒体按键支持音乐和视频；效果由播放器决定。"));
    }

    private void appsPage(LinearLayout p){
        p.addView(smallNote("点击启动 · 长按编辑 / 删除"));
        gap(p,6);
        appsGrid=new LinearLayout(this);
        appsGrid.setOrientation(LinearLayout.VERTICAL);
        p.addView(appsGrid);
        renderApps();
        gap(p,6);
        button(p,"＋ 添加电视 App",PANEL,0,()->editApp(-1));
        gap(p,5);
        p.addView(smallNote("由电视 Google Play 启动；启动模式在第 6 页设置。"));
    }

    private void connectionPage(LinearLayout p){
        p.addView(smallNote("手表与电视必须位于可互通的局域网"));
        gap(p,7);
        hostField=input("电视 IP / 主机名",prefs.getString("host",""),
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        p.addView(hostField);
        gap(p,8);
        LinearLayout buttons=row(p);
        button(buttons,"搜索电视",PANEL,1,this::startDiscovery);
        button(buttons,"连接电视",GREEN,1,this::connect);
        gap(p,8);
        button(p,"首次配对 → 第 5 页",PANEL,0,()->goToPage(4));
        gap(p,8);
        p.addView(smallNote("搜索不到时，输入电视的 IPv4 地址。蓝牙代理网络不一定支持局域网访问。"));
    }

    private void pairingPage(LinearLayout p){
        p.addView(smallNote("先点首次配对，再看电视上的六位配对码"));
        gap(p,7);
        button(p,"① 请求电视显示配对码",PANEL,0,this::startPair);
        gap(p,8);
        pinField=input("六位配对码", "",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        p.addView(pinField);
        gap(p,8);
        button(p,"② 确认配对并连接",GREEN,0,this::finishPair);
        gap(p,7);
        button(p,"忘记这台电视的配对",RED,0,()->new AlertDialog.Builder(this)
                .setTitle("清除配对？").setMessage("清除后需要重新从电视获取六位验证码。")
                .setNegativeButton("取消",null).setPositiveButton("清除",(d,w)->forgetPair()).show());
        gap(p,6);
        p.addView(smallNote("配对证书仅保存在这块手表上。"));
    }

    private void settingsPage(LinearLayout p){
        p.addView(smallNote("Google Play 启动方式（点击循环切换）"));
        gap(p,7);
        launchModeButton=button(p,"",GREEN,0,this::cyclePlayMode);
        refreshPlayModeText();
        gap(p,7);
        button(p,"手动确定 / 打开",PANEL,0,()->key(23,"电视确定键"));
        gap(p,7);
        button(p,"＋ 添加电源快捷方式",PANEL,0,()->pinPowerShortcut(
                QuickActionActivity.ACTION_TOGGLE,"tv-toggle","Google TV 开关",R.drawable.ic_shortcut_toggle));
        gap(p,6);
        p.addView(smallNote("仅在手表启动器支持固定快捷方式时可添加；首页始终有电源键。"));
        gap(p,6);
        p.addView(smallNote("自动确定会盲按一次，可能误触安装等按钮。默认采用手动确认。"));
        gap(p,6);
        p.addView(smallNote("本应用不控制 HDMI-CEC；发出请求不代表电视执行成功。"));
    }

    private TextView smallNote(String s){
        TextView t=label(s,11,SUB,false);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(2),dp(2),dp(2),dp(2));return t;
    }
    private void emptyCell(LinearLayout parent){
        View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(0,dp(controlHeight),1));
    }
    private void goToPage(int p){
        int index=Math.max(0,Math.min(PAGE_NAMES.length-1,p));
        for(int i=0;i<pages.size();i++)pages.get(i).setVisibility(i==index?View.VISIBLE:View.GONE);
        currentPage=index;
        pageTitle.setText(PAGE_NAMES[index]+" · "+(index+1)+"/"+PAGE_NAMES.length);
        // Retain scroll position for a page when users return to it.
    }
    @Override public boolean dispatchTouchEvent(MotionEvent ev){
        if(ev.getActionMasked()==MotionEvent.ACTION_DOWN){
            downX=ev.getX();downY=ev.getY();
            View focus=getCurrentFocus();
            touchStartedInInput=focus instanceof EditText && isInsideView(focus,ev.getRawX(),ev.getRawY());
        }else if(ev.getActionMasked()==MotionEvent.ACTION_UP && !touchStartedInInput){
            float dx=ev.getX()-downX,dy=ev.getY()-downY;
            if(Math.abs(dy)>dp(65) && Math.abs(dy)>Math.abs(dx)*1.35f){
                ScrollView active=pages.get(currentPage);
                boolean scrollMore=active.canScrollVertically(dy<0?1:-1);
                // Scroll long pages before switching; swipe again at their edge.
                if(!scrollMore){
                    MotionEvent cancel=MotionEvent.obtain(ev);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);cancel.recycle();
                    goToPage(currentPage+(dy<0?1:-1));
                    return true;
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }
    private boolean isInsideView(View v,float rawX,float rawY){
        int[] loc=new int[2];v.getLocationOnScreen(loc);
        return rawX>=loc[0]&&rawX<=loc[0]+v.getWidth()&&rawY>=loc[1]&&rawY<=loc[1]+v.getHeight();
    }
    @Override public boolean onGenericMotionEvent(MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_SCROLL && event.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER)){
            float change=event.getAxisValue(MotionEvent.AXIS_SCROLL);
            if(Math.abs(change)>0.01f){goToPage(currentPage+(change<0?1:-1));return true;}
        }
        return super.onGenericMotionEvent(event);
    }

    /** Legacy launcher pins remain owned by the user; mark old wake/sleep pins disabled. */
    private void disableLegacyShortcuts(){
        try{
            ShortcutManager shortcuts=getSystemService(ShortcutManager.class);
            if(shortcuts!=null)shortcuts.disableShortcuts(
                    java.util.Arrays.asList("tv-wake","tv-sleep"),"旧版快捷方式已停用，请在桌面删除");
        }catch(Exception ignored){}
    }

    private int playMode(){return prefs.getInt("play_mode_v42",2);}
    private void cyclePlayMode(){
        int next=playMode()==2?1:playMode()==1?0:2;
        prefs.edit().putInt("play_mode_v42",next).apply();
        refreshPlayModeText();
    }
    private void refreshPlayModeText(){
        if(launchModeButton==null)return;
        int mode=playMode();
        String text=mode==0?"启动方式：Play 直启尝试":
                mode==1?"启动方式：详情页 + 自动按确定":"启动方式：详情页 + 手动确认";
        launchModeButton.setText(text+"  ↻");
    }

    private void restoreApps(){
        String saved=prefs.getString("custom_tv_apps_v4",null);
        if(saved==null){
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
            return;
        }
        try{
            JSONArray array=new JSONArray(saved);
            for(int i=0;i<array.length();i++){
                JSONObject obj=array.getJSONObject(i);
                String name=obj.optString("name","").trim();
                String target=obj.optString("target","").trim();
                if(!name.isEmpty()&&!target.isEmpty())savedApps.add(new SavedApp(name,target));
            }
        }catch(Exception ignored){
            savedApps.clear();
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
        }
    }
    private void persistApps(){
        JSONArray json=new JSONArray();
        for(SavedApp a:savedApps){
            JSONObject o=new JSONObject();
            try{o.put("name",a.name);o.put("target",a.target);}catch(Exception ignored){}
            json.put(o);
        }
        prefs.edit().putString("custom_tv_apps_v4",json.toString()).apply();
    }
    private void renderApps(){
        if(appsGrid==null)return;
        appsGrid.removeAllViews();
        for(int i=0;i<savedApps.size();i+=2){
            LinearLayout r=row(appsGrid);
            for(int j=i;j<Math.min(i+2,savedApps.size());j++){
                final int at=j;
                SavedApp item=savedApps.get(j);
                Button btn=button(r,item.name,at<2?GREEN:PANEL,1,()->launchViaPlay(item));
                btn.setOnLongClickListener(v->{editApp(at);return true;});
            }
            if(i+1>=savedApps.size())spacerButton(r);
            gap(appsGrid,9);
        }
        if(savedApps.isEmpty())appsGrid.addView(label("还没有快捷 App，点击下方添加。",12,SUB,false));
    }
    private void editApp(int index){
        boolean editing=index>=0&&index<savedApps.size();
        if(editing){
            SavedApp current=savedApps.get(index);
            new AlertDialog.Builder(this).setTitle(current.name)
                    .setItems(new String[]{"修改名称或包名","删除此快捷方式","取消"},(d,which)->{
                        if(which==0)promptAppName(index);
                        else if(which==1)new AlertDialog.Builder(this).setTitle("删除「"+current.name+"」？")
                                .setNegativeButton("取消",null)
                                .setPositiveButton("删除",(dialog,button)->{
                                    savedApps.remove(index);persistApps();renderApps();
                                }).show();
                    }).show();
        }else promptAppName(-1);
    }
    private void promptAppName(int index){
        boolean editing=index>=0 && index<savedApps.size();
        String existing=editing?savedApps.get(index).name:"";
        EditText field=input("快捷名称，如 MX Player",existing,InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("电视 App 名称")
                .setView(dialogInput(field)).setNegativeButton("取消",null)
                .setPositiveButton("下一步",(d,w)->{
                    String name=field.getText().toString().trim();
                    if(name.isEmpty() || name.length()>32){showStatus("名称为 1–32 个字符，请重新填写",true);return;}
                    promptAppPackage(index,name);
                }).show();
    }
    private void promptAppPackage(int index,String name){
        boolean editing=index>=0 && index<savedApps.size();
        String existing=editing?savedApps.get(index).target:"";
        EditText field=input("如 com.qobuz.music",existing,InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("Android 包名")
                .setView(dialogInput(field)).setNegativeButton("取消",null)
                .setPositiveButton("保存",(d,w)->{
                    String target=field.getText().toString().trim();
                    if(!validTarget(target)){showStatus("无效的 Android 包名，请重新编辑",true);return;}
                    if(editing){SavedApp app=savedApps.get(index);app.name=name;app.target=target;}
                    else savedApps.add(new SavedApp(name,target));
                    persistApps();renderApps();
                    showStatus("已保存电视 App："+name,false);
                }).show();
    }
    private LinearLayout dialogInput(EditText field){
        LinearLayout wrapper=new LinearLayout(this);
        wrapper.setPadding(dp(12),dp(8),dp(12),dp(8));wrapper.addView(field);
        return wrapper;
    }

    private void pinPowerShortcut(String action,String id,String shortLabel,int iconId){
        String host=saveHost();if(host==null)return;
        if(prefs.getString("tv_fingerprint","").isEmpty()){
            showStatus("请先完成 Google TV 六位代码配对，再添加桌面快捷方式。",true);return;
        }
        ShortcutManager manager=getSystemService(ShortcutManager.class);
        if(manager==null||!manager.isRequestPinShortcutSupported()){
            showStatus("当前手机桌面不支持自动添加固定快捷方式，可尝试长按 App 图标查看快捷功能。",true);return;
        }
        Intent intent=new Intent(this,QuickActionActivity.class);
        intent.setAction(action);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        ShortcutInfo shortcut=new ShortcutInfo.Builder(this,id)
                .setShortLabel(shortLabel)
                .setLongLabel(shortLabel+"（Wi-Fi 遥控）")
                .setIcon(Icon.createWithResource(this,iconId))
                .setIntent(intent).build();
        try {
            if(manager.requestPinShortcut(shortcut,null))
                showStatus("请在 Android 弹出的确认窗口里添加「"+shortLabel+"」到桌面。",false);
            else showStatus("未能请求添加快捷方式，请检查当前桌面启动器。",true);
        } catch(Exception e){showStatus("无法添加桌面快捷方式："+e.getMessage(),true);}
    }

    private static boolean validTarget(String raw){
        return raw!=null && raw.length()<=150 &&
                raw.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+");
    }

    /** One tap launches via Google Play. Modes are explicitly chosen by user.
     *  In auto mode a delayed DPAD_CENTER may activate the wrong Play control.
     */
    private void launchViaPlay(SavedApp app){
        if(!validTarget(app.target)){
            showStatus("「"+app.name+"」不是有效包名。请长按修改成 Android 包名。",true);return;
        }
        String host=saveHost();if(host==null)return;
        final int mode=playMode();
        io.execute(()->{
            try{
                ensureConnected(host);
                if(mode==0){
                    remote.launchApp(app.target);
                    showStatus("已尝试通过 Google Play 一键启动「"+app.name+"」。若只出现商店，请切换到自动确认模式。",false);
                }else{
                    remote.openAppStorePage(app.target);
                    if(mode==1){
                        // Give the TV Play Store time to show the details screen.
                        // No foreground/focus telemetry: this is opt-in only.
                        Thread.sleep(1900);
                        remote.sendKey(23);
                        showStatus("已发送「"+app.name+"」Play 详情页与自动确定指令。请检查电视是否真正打开 App。",false);
                    }else{
                        showStatus("已请求打开电视 Google Play 的「"+app.name+"」详情页，可按下方“手动确定 / 打开”。",false);
                    }
                }
            }catch(InterruptedException e){
                Thread.currentThread().interrupt();showStatus("启动操作已中断",true);
            }catch(Exception e){showStatus("Google Play 启动请求失败："+e.getMessage(),true);}
        });
    }

    private void key(int code,String name){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                ensureConnected(host);
                remote.sendKey(code);
                showStatus("已发送「"+name+"」。具体响应由电视和当前播放器决定。",false);
            }catch(Exception e){showStatus("发送「"+name+"」失败："+e.getMessage(),true);}
        });
    }
    private String saveHost(){
        String host=hostField.getText().toString().trim();
        if(host.isEmpty()||host.contains("://")||host.contains("/")||host.contains(" ")||host.contains(":")){
            showStatus("请输入 Google TV 的有效 IPv4 地址或主机名",true);return null;
        }
        prefs.edit().putString("host",host).apply();return host;
    }
    private void ensureConnected(String host)throws Exception{
        if(remote==null||identity==null)throw new IllegalStateException("遥控器尚未初始化");
        if(!remote.isReady()){
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("请先完成六位码配对");
            remote.connect(host,fp);
        }
    }
    private void connect(){String host=saveHost();if(host!=null)io.execute(()->connectInternal(host));}
    private void connectInternal(String host){
        if(identity==null){showStatus("证书尚未初始化",true);return;}
        try{
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("未配对，请先输入电视显示的六位代码");
            showStatus("正在连接 Google TV："+host,false);
            remote.connect(host,fp);
            showStatus("已连接 Google TV，可以操作本机电源、启动 App 和媒体控制。",false);
        }catch(Exception e){showStatus("连接失败："+e.getMessage(),true);}
    }
    private void startPair(){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                if(identity==null)throw new IllegalStateException("证书尚未初始化");
                if(pairing!=null)pairing.close();
                if(remote!=null)remote.close();
                pairing=new PairingClient(identity);
                showStatus("请求电视显示六位配对码…",false);
                pairing.begin(host);
                showStatus("请将 Google TV 上显示的六位代码填入下方。",false);
            }catch(Exception e){showStatus("开始配对失败："+e.getMessage(),true);}
        });
    }
    private void finishPair(){
        String pin=pinField.getText().toString().trim();
        String host=saveHost();if(host==null)return;
        if(!pin.matches("(?i)[0-9a-f]{6}")){showStatus("请输入 6 位配对码（0–9 或 A–F）",true);return;}
        io.execute(()->{
            try{
                if(pairing==null)throw new IllegalStateException("请先点击首次配对");
                String fp=pairing.finish(pin);
                prefs.edit().putString("tv_fingerprint",fp).apply();
                runOnUiThread(()->pinField.setText(""));
                showStatus("配对成功，正在连接…",false);
                connectInternal(host);
            }catch(Exception e){showStatus("配对失败："+e.getMessage()+"，可以重新开始配对。",true);}
        });
    }
    private void forgetPair(){
        io.execute(()->{
            if(pairing!=null)pairing.close();
            if(remote!=null)remote.close();
            prefs.edit().remove("tv_fingerprint").apply();
            showStatus("本机配对记录已清除；再次连接需重新输入配对码。",false);
        });
    }
    private void startDiscovery(){
        try{
            if(discovery!=null){showStatus("正在搜索电视…",false);return;}
            nsd=(NsdManager)getSystemService(Context.NSD_SERVICE);
            try{
                WifiManager wifi=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if(wifi!=null){
                    multicastLock=wifi.createMulticastLock("google-tv-watch-discovery");
                    multicastLock.setReferenceCounted(false);multicastLock.acquire();
                }
            }catch(Exception ignored){}
            discovery=new NsdManager.DiscoveryListener(){
                @Override public void onDiscoveryStarted(String type){showStatus("局域网搜索中…",false);}
                @Override public void onServiceFound(NsdServiceInfo service){
                    if(resolving)return;
                    resolving=true;
                    try{nsd.resolveService(service,new NsdManager.ResolveListener(){
                        @Override public void onServiceResolved(NsdServiceInfo found){
                            resolving=false;
                            if(found.getHost()==null)return;
                            String ip=found.getHost().getHostAddress();
                            runOnUiThread(()->{
                                hostField.setText(ip);prefs.edit().putString("host",ip).apply();
                                showStatus("找到电视："+found.getServiceName()+" · "+ip,false);
                            });stopDiscovery();
                        }
                        @Override public void onResolveFailed(NsdServiceInfo i,int err){
                            resolving=false;showStatus("发现设备，但解析失败（"+err+"），请手动填写 IP",true);
                        }
                    });}catch(Exception ex){resolving=false;showStatus("搜索异常："+ex.getMessage(),true);}
                }
                @Override public void onServiceLost(NsdServiceInfo service){}
                @Override public void onDiscoveryStopped(String type){}
                @Override public void onStartDiscoveryFailed(String type,int err){
                    showStatus("搜索失败（"+err+"），可手动输入 IP",true);stopDiscovery();
                }
                @Override public void onStopDiscoveryFailed(String type,int err){}
            };
            nsd.discoverServices("_androidtvremote2._tcp.",NsdManager.PROTOCOL_DNS_SD,discovery);
        }catch(Exception e){discovery=null;showStatus("无法搜索："+e.getMessage(),true);}
    }
    private void stopDiscovery(){
        NsdManager.DiscoveryListener d=discovery;discovery=null;
        if(nsd!=null&&d!=null)try{nsd.stopServiceDiscovery(d);}catch(Exception ignored){}
        if(multicastLock!=null){try{if(multicastLock.isHeld())multicastLock.release();}catch(Exception ignored){}multicastLock=null;}
    }
    private void showStatus(String text,boolean error){
        runOnUiThread(()->{if(statusView!=null){statusView.setText(text);statusView.setTextColor(error?0xffffa3aa:ACCENT);}});
    }

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private EditText input(String hint,String value,int type){
        EditText e=new EditText(this);e.setText(value);e.setHint(hint);
        e.setTextColor(LIGHT);e.setHintTextColor(SUB);e.setTextSize(13);
        e.setInputType(type);e.setSingleLine(true);
        e.setSelectAllOnFocus(true);
        e.setPadding(dp(11),dp(8),dp(11),dp(8));e.setBackground(bg(PANEL));
        e.setMinHeight(dp(45));return e;
    }
    private LinearLayout row(LinearLayout parent){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;
    }
    private void gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private void spacerButton(LinearLayout row){View v=new View(this);row.addView(v,new LinearLayout.LayoutParams(0,dp(controlHeight),1));}
    private Button button(LinearLayout parent,String label,int color,int weight,Runnable act){
        Button b=new Button(this);b.setText(label);b.setTextColor(LIGHT);b.setAllCaps(false);
        b.setTextSize(12);b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setMinimumWidth(0);
        b.setBackground(bg(color));
        b.setPadding(dp(2),dp(2),dp(2),dp(2));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(weight==0?-1:0,dp(controlHeight),weight);
        if(parent.getOrientation()==LinearLayout.HORIZONTAL && parent.getChildCount()>0)p.leftMargin=dp(4);
        parent.addView(b,p);b.setOnClickListener(v->act.run());return b;
    }
    private GradientDrawable bg(int col){GradientDrawable d=new GradientDrawable();d.setColor(col);d.setCornerRadius(dp(12));return d;}
    @Override protected void onDestroy(){
        stopDiscovery();
        io.execute(()->{if(pairing!=null)pairing.close();if(remote!=null)remote.close();});
        io.shutdown();super.onDestroy();
    }
}
