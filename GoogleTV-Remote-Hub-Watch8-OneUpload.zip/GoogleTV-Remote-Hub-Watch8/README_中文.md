# Google TV Remote Hub Watch 8 · V4.2 分页独立手表版

## 安装架构
- **只在 Wear OS 手表安装本项目构建的 `watch8-debug.apk`**，不需要在电视安装 APK；也不依赖手机 App 中转。
- 手机原来的 V4.2 APK 保持不变；手表是独立安装包 `com.cecbridge.remotev2.wear`。
- 电视需支持 Android TV Remote Protocol v2，且手表能够通过 Wi-Fi / 可路由局域网访问电视的 6466/6467 端口。
- 新安装的手表保有自己的 TLS 身份，请在手表上独立完成六位码配对；手机证书不会同步到手表。

## Watch 8 六个页面（上滑下一页、下滑上一页，也可点底部翻页键）
1. **方向遥控**：电源切换；上/下/左/右/确定；返回/主页/菜单（圆形表盘适配的 3×3 九宫格）。
2. **媒体控制**：上一首/段、播放暂停、下一首/段、快退、快进、左右回退/前进、停止（3 行紧凑按钮）；音乐和视频通用。
3. **启动电视应用**：Kodi、Qobuz 默认快捷方式；添加其他包名；长按编辑/删除；保存到本地。
4. **连接电视**：填电视 IP/主机名，搜索电视，连接已配对电视。
5. **首次配对**：请求电视显示六位配对码，手表输入并确认，忘记已配对电视。
6. **启动与设置**：三种 Google Play 启动模式（直启尝试、详情页自动确认、详情页手动确认），手动按确定，尝试添加启动器电源快捷方式，安全提示。

页面底部显示连接/操作反馈，点击状态栏可查看完整文字。表冠旋转也可尝试翻页（以机型输入事件为准）。页内内容超出一屏时可先上下滚动，触及边缘后继续滑动翻页。

## 保留原版协议与限制
- 保留 PairingClient、IdentityStore、RemoteSession、Proto 全部原始协议功能，不安装 TV Bridge。
- 保留 NSD 搜索（`_androidtvremote2._tcp.`），并新增 Wi-Fi multicast lock 以改善搜索。
- Google Play 直启与详情页启动是遥控请求，不能保证每台 Google TV 真正打开应用。
- **自动确认模式有误点安装/其他按钮的风险**，默认仍是“详情页 + 手动确认”。
- 媒体方向键对视频的跳转行为由实际播放器决定。
- 手表系统的应用启动器一般不支持手机式“桌面固定快捷方式”：保留了发起请求的入口，若不支持会明确提示；第 1 页的电源键始终可用。
- 不控制 HDMI-CEC，不读取电视屏幕和焦点状态。

## GitHub Actions 编译（一个 ZIP 上传）
1. 新建空仓库，例如 `GoogleTV-Remote-Hub-Watch8`。
2. 把 `GoogleTV-Remote-Hub-Watch8-OneUpload.zip` 上传到仓库根目录（不要解压）。
3. 把随包单独提供的 `build-apk.yml` 文件放到 `.github/workflows/build-apk.yml`（可以直接复制本项目 `.github/workflows/build-apk.yml` 的内容）。
4. GitHub Actions > Build Google TV Remote Hub Watch8 APK > Run workflow。
5. 下载 Artifacts 中的 `GoogleTV-Remote-Hub-Watch8-APK`，安装 `watch8-debug.apk` 到手表。

## 源码检查说明
本包已做 ZIP 完整性、Manifest 和源代码静态检查。**当前环境未安装 Android SDK/Gradle，未实际生成 APK，也未执行 Watch 8 真机测试。**
